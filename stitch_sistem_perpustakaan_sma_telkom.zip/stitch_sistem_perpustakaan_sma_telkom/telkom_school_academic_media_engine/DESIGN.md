---
name: Telkom School Academic & Media Engine
colors:
  surface: '#f9f9ff'
  surface-dim: '#c7dbff'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eeff'
  surface-container-high: '#dee8ff'
  surface-container-highest: '#d5e3ff'
  on-surface: '#021c3a'
  on-surface-variant: '#5b403f'
  inverse-surface: '#1b3150'
  inverse-on-surface: '#ebf1ff'
  outline: '#906f6e'
  outline-variant: '#e4bdbc'
  surface-tint: '#bd0a2e'
  primary: '#ba042b'
  on-primary: '#ffffff'
  primary-container: '#de2b41'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb3b2'
  secondary: '#525f73'
  on-secondary: '#ffffff'
  secondary-container: '#d6e3fb'
  on-secondary-container: '#586579'
  tertiary: '#565d5e'
  on-tertiary: '#ffffff'
  tertiary-container: '#6f7677'
  on-tertiary-container: '#f7feff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad9'
  primary-fixed-dim: '#ffb3b2'
  on-primary-fixed: '#410008'
  on-primary-fixed-variant: '#92001f'
  secondary-fixed: '#d6e3fb'
  secondary-fixed-dim: '#bac7de'
  on-secondary-fixed: '#0f1c2d'
  on-secondary-fixed-variant: '#3b485a'
  tertiary-fixed: '#dde4e5'
  tertiary-fixed-dim: '#c1c8c9'
  on-tertiary-fixed: '#161d1e'
  on-tertiary-fixed-variant: '#414849'
  background: '#f9f9ff'
  on-background: '#021c3a'
  surface-variant: '#d5e3ff'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.015em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.005em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: '0'
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: '0'
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 0.75rem
  gutter-lg: 2rem
  margin: 1.5rem
  margin-sm: 1rem
  margin-lg: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes a high-performance, structured, and accessible digital environment for modern secondary education and media resource administration. The visual direction balances academic rigor with telecommunications-inspired technological precision. 

### Aesthetic Philosophy
The system combines **Corporate/Modern Precision** with **Functional Editorial Clarity**:
- **Structured Architectural Flow:** Layouts prioritize clarity, information hierarchy, and low cognitive friction during high-frequency tasks such as roll calls, class attendance logging, catalog searching, and digital book reservations.
- **Academic Authority & Energy:** A controlled dual palette—anchored by Telkom's energetic crimson red and tempered by commanding deep slate navy—imparts institutional discipline alongside active engagement.
- **Operational Ergonomics:** Micro-interactions emphasize confirmation, data validation, and instantaneous status assessment through crisp border definition and subtle atmospheric depth rather than heavy ornamentation.

## Colors

The palette is engineered for institutional presence, operational legibility, and effortless data scanning under sustained daylight use.

### Palette Architecture
- **Primary (`#F33C4E`):** The signature vibrant Telkom crimson. Reserved for high-priority interactive touchpoints, active tab indicators, key call-to-action buttons (e.g., "Submit Attendance", "Borrow Book"), and critical status badges (e.g., "Overdue").
- **Secondary (`#263345`):** Deep Telkom slate navy. Serves as the bedrock for navigation bars, sidebar containers, primary titles, high-emphasis text, and active interactive borders, balancing the warmth of the primary red.
- **Tertiary (`#A4ABAC`):** Academic silver-teal. Deployed for informational counters, metadata tags, secondary category filters in the library index, and progress monitors.
- **Neutral (`#435879`):** Balanced graphite slate. Generates secondary copy, metadata stamps, divider lines, and neutral field borders.

### Functional Canvas & Surface Strategy
- **App Canvas Base:** `#F8F9FF` — A soft, cool off-white that prevents screen fatigue while maintaining contrast against white cards.
- **Surface Elevation 0 (Card/Tile Base):** `#FFFFFF` — Pure white for crisp contrast against `#F8F9FF`.
- **Surface Elevation 1 (Interactive Inset/Sub-wells):** `#EFF4FF` — For table headers, nested record panels, and inactive input strokes.
- **Border Default:** `#D6E3FB` — Deliberate, high-clarity structural division.

## Typography

The type system pairs **Plus Jakarta Sans** for expressive, geometric, and authoritative headings with **Inter** for dense, ultra-legible body text and administrative data displays.

### Typographic Governance
- **Headlines & Section Entry (Plus Jakarta Sans):** Delivers clean contemporary energy with slightly tightened tracking for high impact in dashboard overviews, student rosters, and catalog sections.
- **Data Points & Interface Controls (Inter):** Leveraged for tabular figures, attendance matrix records, and status badges. Tabular numerals (`tnum`) must be enforced for ISBN entries, student IDs (NISN), catalog call numbers, timestamps, and attendance counts.
- **Letter Spacing:** All small labels (`label-sm`, `label-md`) use positive tracking (+0.02em to +0.04em) and uppercase transformation when used as categorical badges or loan status tags to maximize glanceable recognition.

## Layout & Spacing

The portal uses a structured **12-column responsive fluid grid** anchored by desktop layouts and collapsible sidebar structures.

### Grid & Viewport Rules
- **Desktop (1280px and above):** 12-column grid, `margin-lg` (2.5rem) exterior frame padding, fixed 260px left-hand academic sidebar, `gutter` (1.5rem) between layout modules.
- **Tablet (768px – 1279px):** 8-column layout, `margin` (1.5rem), `gutter-sm` (0.75rem) to compress attendance tables while keeping data touch targets at a minimum of 44px. Sidebar transforms into an off-canvas drawer or compact rail.
- **Mobile (Below 768px):** 4-column layout, `margin-sm` (1rem), with tables transforming into card lists or horizontal swipe containers with fixed student name columns.

### Vertical Rhythm
Interface components adhere strictly to an 8-point vertical coordinate system. Input fields, attendance switch pills, and book catalog cards align across standardized baseline multiples (32px, 40px, 48px).

## Elevation & Depth

Visual hierarchy is maintained through **crisp low-contrast outlines coupled with soft ambient micro-shadows**. This avoids visual clutter during data-dense administrative shifts.

### Depth Hierarchy
1. **Level 0 (Flat Ground):** The canvas (`#F8F9FF`). No shadow, no outline.
2. **Level 1 (Card & Content Blocks):** 1px solid border in `#D6E3FB`, background `#FFFFFF`, accompanied by an ambient drop shadow: `0 1px 3px rgba(38, 51, 69, 0.04), 0 1px 2px rgba(38, 51, 69, 0.02)`.
3. **Level 2 (Interactive Hover & Modals / Popovers):** Elevated surface with 1px border in `#C8D3E0`, accompanied by a subtle slate shadow: `0 8px 16px -4px rgba(38, 51, 69, 0.08), 0 4px 6px -2px rgba(38, 51, 69, 0.03)`.
4. **Level 3 (Sticky Controls & Barcode Scanner Overlay):** `0 16px 32px -8px rgba(38, 51, 69, 0.12)`.

## Shapes

The design system adopts **Level 2 Roundedness** (0.5rem / 8px baseline) to project a disciplined, approachable, and modern academic aesthetic.

### Application Tokens
- **Base Components (`rounded` / 8px):** Input inputs, table record containers, drop-downs, catalog thumbnail frames, and standard buttons.
- **Compound Cards (`rounded-lg` / 16px):** Attendance overview panels, book detail summaries, and student profile header blocks.
- **Deep Containers (`rounded-xl` / 24px):** Primary modal dialogues and camera scan viewports.
- **Full Pill (`rounded-full`):** Status indicator tags, class badges (e.g., `XII-RPL-1`), attendance action switches (Present, Late, Absent, Excused), and student avatar frames.

## Components

### Buttons
- **Primary:** Background in primary crimson (`#F33C4E`), label in pure white, 8px border-radius. On hover, background deepens. Active state: scale transforms down to `0.98`.
- **Secondary:** Background in deep slate navy (`#263345`), text white. Ideal for secondary batch operations (e.g., "Export Roster", "Print Library Slips").
- **Outline / Ghost:** 1.5px solid border in `#D6E3FB`, text `#263345`, background transparent. Hover transitions to `#F8F9FF`.

### Status Badges & Class Tags
- **Class Identifier Badges:** Pill-shaped, neutral slate tone (`#EFF4FF`), 1px border `#D6E3FB`, typography `label-sm` in `#263345`.
- **Loan Status Badges:**
  - *Available:* `#E6F5F0` background, `#0E7A53` text, 1px border `#B4E8D4`.
  - *Borrowed / In Circulation:* `#EFF4FA` background, `#1D5CA8` text, 1px border `#C8DCF0`.
  - *Overdue:* `#FDF0F1` background, `#F33C4E` text, 1px border `#F9CBD0`.
  - *Reserved:* `#FDF6E8` background, `#9A6700` text, 1px border `#FCE2B0`.

### Attendance Flow Controller
- Grouped 4-segment toggle button for quick roll call (Hadir / Terlambat / Izin / Alpa).
- Inactive segment: background `#FFFFFF`, text `#435879`, border `#D6E3FB`.
- Active segment: 
  - *Hadir (Present):* Green accent fill (`#0E7A53`), white text.
  - *Terlambat (Late):* Amber fill (`#D9822B`), white text.
  - *Izin (Excused):* Slate navy fill (`#263345`), white text.
  - *Alpa (Absent):* Primary crimson fill (`#F33C4E`), white text.

### Library Catalog Cards
- Minimum 3:4 aspect ratio for book jacket display with an inset 1px inner border to preserve contrast on white book covers.
- Metadata layout includes bold title in Plus Jakarta Sans (`headline-sm`), author and call number in Inter (`body-sm`), and anchored loan status badge positioned at the card header.
- Quick action CTA for "Pinjam" (Borrow) or "Detail Buku" positioned flush along the card base.

### Form Inputs & Barcode/NISN Scanner Fields
- Height: 44px for standard inputs; 52px for rapid barcode / RFID scanning fields.
- Normal state: `#FFFFFF` fill, 1px solid border `#D6E3FB`, typography `body-md` in `#263345`.
- Focus state: Border transitions to `#263345` with an outer focus ring: `0 0 0 3px rgba(38, 51, 69, 0.12)`.